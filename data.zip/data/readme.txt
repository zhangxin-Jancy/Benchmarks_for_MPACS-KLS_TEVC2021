Number_of_edges Number_of_points
Information of each edge
Information of each point (including number of choices and the time and the cost of each choice)